import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}


class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);

        listModel = new DefaultListModel();


        //Updated the top Five Destinations and added images and links to the image.
        addDestinationNameAndPicture("1. Paris, France (Visit the Iconic Eiffel Tower during your trip to France.)", new ImageIcon(getClass().getResource("/resources/France.jpg")),"https://commons.wikimedia.org/wiki/File:Tour_eiffel_at_sunrise_from_the_trocadero.jpg");
        addDestinationNameAndPicture("2. London, England (Discover the History of London, Big Ben, and Buckingham Palace.)", new ImageIcon(getClass().getResource("/resources/London.jpg")),"https://commons.wikimedia.org/wiki/File:Elizabeth_Tower_2014-09-21_205MP.jpg");
        addDestinationNameAndPicture("3. Hawaii (Take in the beautiful beaches, countysides, and surf.)", new ImageIcon(getClass().getResource("/resources/Hawaii.jpg")),"https://commons.wikimedia.org/wiki/File:Sunset_next_to_Waikiki_Beach,_Oahu,_Hawai,_USA1.jpg");
        addDestinationNameAndPicture("4. Alaska (Discover the last American Frontier and the Beauty of Alaska.)", new ImageIcon(getClass().getResource("/resources/Alaska.jpg")),"https://commons.wikimedia.org/wiki/File:Glaciar_de_Aialik,_Bah%C3%ADa_de_Aialik,_Seward,_Alaska,_Estados_Unidos,_2017-08-21,_DD_58-64_PAN.jpg");
        addDestinationNameAndPicture("5. Australia (Enjoy your visit to the Land Down Under.)", new ImageIcon(getClass().getResource("/resources/Australia.jpg")),"https://commons.wikimedia.org/wiki/File:Sydney_Opera_House_and_Harbour_Bridge,_southeast_view_20230224_1.jpg");
        
        JList list = new JList(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(8); // Increased value from 2 to 8 to increase area aroudn text and icon
        renderer.setBackgroundNonSelectionColor(Color.ORANGE); //Background color for non selected items changed to orange
        renderer.setBackgroundSelectionColor(Color.GREEN); //Background color for selected items changed to green
        renderer.setForegroundSelectionColor(Color.RED); //Text color for selected items changed to red

        list.setCellRenderer(renderer);
        list.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int index = list.locationToIndex(e.getPoint()); //Needed to know what is being clicked by the mouse
                TextAndIcon item = listModel.getElementAt(index); //Retreives the proper item based on click
                if (item.getLink() != null) { //Verifies that there is a link assigned to item being clicked
                    try {
                        Desktop.getDesktop().browse(new URI(item.getLink())); //Opens the link in a web browser
                    } catch (IOException | URISyntaxException ex) {
                        ex.printStackTrace(); //Handles any errors encounterd while openning links
                    }
                }
            }
        });

        getContentPane().add(scrollPane, BorderLayout.CENTER);

        JLabel nameLabel = new JLabel("Danny Forte"); //My name in a label
        nameLabel.setHorizontalAlignment(SwingConstants.CENTER); //Center Alligned
        nameLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Sets font, style, and size
        nameLabel.setForeground(Color.BLACK); // Sets text color to black

        JPanel panel = new JPanel(); //Panel to hold the label
        panel.add(nameLabel);

        getContentPane().add(panel, BorderLayout.NORTH); //Puts panel on top of screen
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}


class TextAndIcon {
    private String text;
    private Icon icon;
    private String link; // Private field to store links

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
        this.link = link;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public String getLink() { //Getter method for links
        return link;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}
    public void setLink(String link) { // new setter method for links
        this.link = link;
}

class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);

    private Border insideBorder;
    private Color backgroundSelectionColor = Color.orange;
    private Color backgroundNonSelectionColor = Color.green;
    private Color foregroundSelectionColor = Color.red;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }
    public void setBackgroundSelectionColor(Color color) { //Set backgorund color for curretnly listed item
        this.backgroundSelectionColor = color;
    }

    public void setBackgroundNonSelectionColor(Color color) { //Set backgorund color for items not selected
        this.backgroundNonSelectionColor = color;
    }

    public void setForegroundSelectionColor(Color color) { //Set text color for items listed
        this.foregroundSelectionColor = color;
    }


    public Component getListCellRendererComponent(JList list, Object value,
    int index, boolean isSelected, boolean hasFocus) {
        // The object from the combo box model MUST be a TextAndIcon.
        TextAndIcon tai = (TextAndIcon) value;

        // Sets text and icon on 'this' JLabel.
        setText(tai.getText());
        setIcon(tai.getIcon());

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder;

        if (hasFocus) {
            outsideBorder = UIManager.getBorder("List.focusCellHighlightBorder");
        } else {
            outsideBorder = NO_FOCUS_BORDER;
        }

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // The following methods are overridden to be empty for performance
    // reasons. If you want to understand better why, please read:
    //
    // http://java.sun.com/javase/6/docs/api/javax/swing/DefaultListCellRenderer.html#override

    public void validate() {}
    public void invalidate() {}
    public void repaint() {}
    public void revalidate() {}
    public void repaint(long tm, int x, int y, int width, int height) {}
    public void repaint(Rectangle r) {}
}